package com.example.page;


import com.example.annotation.PageFragement;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

@PageFragement
public class SearchResult extends Base {

    @FindBy(css = "div.g")
    private List<WebElement> results;
	private Object wait;

    public int getCount() {
        return this.results.size();
    
    }

	@Override
	public boolean isAt() {
		// TODO Auto-generated method stub
		return false;
	}
}
